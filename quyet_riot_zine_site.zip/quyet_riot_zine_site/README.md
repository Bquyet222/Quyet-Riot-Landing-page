# QUYET RIOT — Cobain‑Zine Landing (GitHub Pages Ready)

A one‑page, zine‑style site for **Bquyet / Quyet Riot**. Free‑hostable on **GitHub Pages / Netlify / Vercel**.
Uses Google Fonts (*Rock Salt* + *Special Elite*), torn‑paper vibes, collage placeholders, and tape‑stapled buy buttons.

---

## 1) Quick Start (GitHub Pages)

1. Create a repo named e.g. `quyet-riot`.
2. Upload these files (keep the `/assets` folder).
3. In **Settings → Pages**:
   - **Source**: `Deploy from a branch`
   - **Branch**: `main` (or `master`) / root (`/`)
4. Your site will be live at `https://YOUR-USERNAME.github.io/quyet-riot`.

> Tip: Commit message “initial zine site”.

---

## 2) Add Shopify Starter Checkout

- In Shopify admin: **Sales Channels → Buy Button → Create a Buy Button** (or copy your product’s direct checkout URL).
- Open `index.html` and replace `YOUR_SHOPIFY_CHECKOUT_LINK` in the first section’s `<a class="buy" ...>`.
- For a full embed, paste the Buy Button script snippet instead of that `<a>`.

---

## 3) Replace Collage Images

- Put your photos in `/assets/` and overwrite `collage1.png`, `collage2.png`, `collage3.png` (or edit the `src` paths).
- Recommended sizes: at least **1600×1000** for hero‑like images.

---

## 4) Local Preview

Just open `index.html` in your browser to preview.
No build step required.

---

## 5) Customization

- Titles / copy: edit the HTML.
- Colors: in `/assets/styles.css` update the `:root` variables.
- Extra sections: duplicate a `.section` block.
- Add more collage items: duplicate a `<figure>` and point `src` to your image.

---

## Credits

- Fonts: Google Fonts — Rock Salt (handwritten), Special Elite (typewriter).
- Everything else is static and free to host.
